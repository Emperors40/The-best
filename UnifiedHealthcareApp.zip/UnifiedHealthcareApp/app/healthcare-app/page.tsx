import { HealthcareApp } from '@/components/healthcare-app/healthcare-app'

export default function HealthcareAppPage() {
  return <HealthcareApp />
}

