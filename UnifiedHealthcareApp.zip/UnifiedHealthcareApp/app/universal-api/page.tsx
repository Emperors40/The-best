import { UniversalAPI } from '@/components/universal-api/universal-api'

export default function UniversalAPIPage() {
  return <UniversalAPI />
}

