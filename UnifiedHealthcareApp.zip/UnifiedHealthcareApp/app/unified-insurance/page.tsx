import { UnifiedInsurance } from '@/components/unified-insurance/unified-insurance'

export default function UnifiedInsurancePage() {
  return <UnifiedInsurance />
}

