import { TrainingCentreAR } from '@/components/training-centre-ar/training-centre-ar'

export default function TrainingCentreARPage() {
  return <TrainingCentreAR />
}

